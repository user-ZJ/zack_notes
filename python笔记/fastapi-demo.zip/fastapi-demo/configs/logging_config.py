from pydantic_settings import BaseSettings
from pydantic import Field,PositiveInt
from typing import Optional
class LoggingConfig(BaseSettings):
    """
    Logging configs
    """

    LOG_LEVEL: str = Field(
        description="Log output level, default to INFO. It is recommended to set it to ERROR for production.",
        default="INFO",
    )

    LOG_FILE: Optional[str] = Field(
        description="logging output file path",
        default=None,
    )

    LOG_FORMAT: str = Field(
        description="log format",
        default="%(asctime)s.%(msecs)03d %(levelname)s [%(threadName)s] [%(filename)s:%(lineno)d] - %(message)s",
    )

    LOG_DATEFORMAT: Optional[str] = Field(
        description="log date format",
        default=None,
    )
