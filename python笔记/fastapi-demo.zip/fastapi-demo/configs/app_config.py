from pydantic_settings import SettingsConfigDict
from pydantic_settings import BaseSettings
from pydantic import Field,PositiveInt
from typing import Optional
from .logging_config import LoggingConfig

class AppConfig(LoggingConfig):
    PORT: PositiveInt = Field(
        description="deployment port",
        default=9900,
    )


    VERSION: Optional[str] = Field(
        description="",
        default=None,
    )
    
    model_config = SettingsConfigDict(
        # read from dotenv format config file
        env_file=".env",
        env_file_encoding="utf-8",
        frozen=True,
        # ignore extra attributes
        extra="ignore",
    )

    # Before adding any config,
    # please consider to arrange it in the proper config group of existed or added
    # for better readability and maintainability.
    # Thanks for your concentration and consideration.
