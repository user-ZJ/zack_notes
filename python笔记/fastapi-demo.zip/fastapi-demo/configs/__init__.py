from .app_config import AppConfig

app_config = AppConfig()