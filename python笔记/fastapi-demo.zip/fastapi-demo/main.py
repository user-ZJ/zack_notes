# -*- coding:utf-8 -*-
"""
入口函数
"""
import os
import sys
import uvicorn
import logging
from logging.handlers import RotatingFileHandler
from fastapi import FastAPI
from configs import app_config
from fastapi import FastAPI
from controllers.hello import router as hello_router



def create_app():
    app = FastAPI()

    log_handlers = None
    log_file = app_config.LOG_FILE
    if log_file:
        log_dir = os.path.dirname(log_file)
        os.makedirs(log_dir, exist_ok=True)
        log_handlers = [
            RotatingFileHandler(
                filename=log_file,
                maxBytes=1024 * 1024 * 1024,
                backupCount=5,
            ),
            logging.StreamHandler(sys.stdout),
        ]

    logging.basicConfig(
        level=app_config.LOG_LEVEL,
        format=app_config.LOG_FORMAT,
        datefmt=app_config.LOG_DATEFORMAT,
        handlers=log_handlers,
        force=True,
    )

    app.include_router(hello_router)
    return app

app = create_app()

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=app_config.PORT)
