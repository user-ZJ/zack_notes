from fastapi import BackgroundTasks, FastAPI, Request
from fastapi.responses import Response, StreamingResponse
import json

# @app.post("/v1/chat/completions")
# async def generate(request: Request):
#     request_dict = await request.json()
#     stream = request_dict.get("stream", False)
#     # temperature = request_dict.get("temperature")
#     # top_p = request_dict.get("top_p")
#     # top_k = request_dict.get("top_k")
#     # max_new_tokens = request_dict.get("max_tokens")
#     # repetition_penalty = request_dict.get("presence_penalty")
#     do_sample = request_dict.get("do_sample",True)
#     messages = request_dict.get("messages")
#     print(request_dict)
#     print("stream",stream)
#     print("do_sample",do_sample)

#     # if stream:
#     #     return StreamingResponse(stream_results(generate_kwargs),media_type="text/event-stream")
#     # else:
#         # outputs =  model.generate(**generate_kwargs)
#         # offset = len(generate_kwargs["input_ids"][0])
#         # out_text = tokenizer.decode(outputs[0][offset:], skip_special_tokens=True)
#     data = {"choices":[{"message":{"content":""}}]}
#     return Response(json.dumps(data),media_type="application/json")